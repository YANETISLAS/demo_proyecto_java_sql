package formularios;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class formularios extends javax.swing.JFrame {
private Connection conexion;
private Statement st;
private ResultSet rs;
        
    public formularios() {
        initComponents();  
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jp_datos = new javax.swing.JPanel();
        jl_id = new javax.swing.JLabel();
        jl_nombre = new javax.swing.JLabel();
        jl_marca = new javax.swing.JLabel();
        jl_existencias = new javax.swing.JLabel();
        jtf_id = new javax.swing.JTextField();
        jtf_nombre = new javax.swing.JTextField();
        jtf_marca = new javax.swing.JTextField();
        jtf_existencias = new javax.swing.JTextField();
        jp_controles_movimiento = new javax.swing.JPanel();
        jb_siguiente = new javax.swing.JButton();
        jb_ultimo = new javax.swing.JButton();
        jb_anterior = new javax.swing.JButton();
        jb_primero = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jp_controles = new javax.swing.JPanel();
        jb_nuevo = new javax.swing.JButton();
        jb_borrar = new javax.swing.JButton();
        jb_modificar = new javax.swing.JButton();
        jb_guardar = new javax.swing.JButton();
        jb_cancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jp_datos.setBackground(new java.awt.Color(153, 204, 255));
        jp_datos.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jl_id.setText("ID");

        jl_nombre.setText("Nombre");

        jl_marca.setText("Marca");

        jl_existencias.setText("Existencias");

        javax.swing.GroupLayout jp_datosLayout = new javax.swing.GroupLayout(jp_datos);
        jp_datos.setLayout(jp_datosLayout);
        jp_datosLayout.setHorizontalGroup(
            jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_datosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jp_datosLayout.createSequentialGroup()
                        .addComponent(jl_existencias)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtf_existencias, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE))
                    .addGroup(jp_datosLayout.createSequentialGroup()
                        .addGroup(jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jl_nombre)
                            .addComponent(jl_marca)
                            .addComponent(jl_id, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jtf_id, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                            .addComponent(jtf_nombre)
                            .addComponent(jtf_marca))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jp_datosLayout.setVerticalGroup(
            jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_datosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtf_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jl_id))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jl_nombre)
                    .addComponent(jtf_nombre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jl_marca)
                    .addComponent(jtf_marca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(jp_datosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jl_existencias)
                    .addComponent(jtf_existencias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jp_controles_movimiento.setBackground(new java.awt.Color(255, 153, 255));
        jp_controles_movimiento.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jb_siguiente.setText(">>");
        jb_siguiente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_siguienteMouseClicked(evt);
            }
        });

        jb_ultimo.setText(">|");
        jb_ultimo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_ultimoMouseClicked(evt);
            }
        });

        jb_anterior.setText("<<");
        jb_anterior.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_anteriorMouseClicked(evt);
            }
        });

        jb_primero.setText("|<");
        jb_primero.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_primeroMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jp_controles_movimientoLayout = new javax.swing.GroupLayout(jp_controles_movimiento);
        jp_controles_movimiento.setLayout(jp_controles_movimientoLayout);
        jp_controles_movimientoLayout.setHorizontalGroup(
            jp_controles_movimientoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_controles_movimientoLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jb_primero, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jb_anterior, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jb_siguiente, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jb_ultimo, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );
        jp_controles_movimientoLayout.setVerticalGroup(
            jp_controles_movimientoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_controles_movimientoLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jp_controles_movimientoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jb_siguiente)
                    .addComponent(jb_ultimo)
                    .addComponent(jb_anterior)
                    .addComponent(jb_primero))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jLabel1.setBackground(new java.awt.Color(153, 0, 153));
        jLabel1.setFont(new java.awt.Font("Lucida Sans", 1, 14)); // NOI18N
        jLabel1.setText("PRODUCTOS");

        jp_controles.setBackground(new java.awt.Color(255, 255, 153));
        jp_controles.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jb_nuevo.setText("Nuevo");
        jb_nuevo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_nuevoMouseClicked(evt);
            }
        });

        jb_borrar.setText("Borrar");
        jb_borrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_borrarMouseClicked(evt);
            }
        });

        jb_modificar.setText("Modificar");
        jb_modificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_modificarMouseClicked(evt);
            }
        });

        jb_guardar.setText("Guardar");
        jb_guardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_guardarMouseClicked(evt);
            }
        });

        jb_cancelar.setText("Cancelar");
        jb_cancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_cancelarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jp_controlesLayout = new javax.swing.GroupLayout(jp_controles);
        jp_controles.setLayout(jp_controlesLayout);
        jp_controlesLayout.setHorizontalGroup(
            jp_controlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_controlesLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jp_controlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jb_nuevo, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                    .addComponent(jb_guardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jp_controlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jb_borrar, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                    .addComponent(jb_cancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jb_modificar)
                .addContainerGap(54, Short.MAX_VALUE))
        );
        jp_controlesLayout.setVerticalGroup(
            jp_controlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_controlesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jp_controlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jb_nuevo)
                    .addComponent(jb_borrar)
                    .addComponent(jb_modificar))
                .addGap(18, 18, 18)
                .addGroup(jp_controlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jb_guardar)
                    .addComponent(jb_cancelar))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jp_datos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jp_controles_movimiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jp_controles, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(167, 167, 167)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jp_datos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jp_controles_movimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jp_controles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void Conectar(){
    try{
        conexion=DriverManager.getConnection("jdbc:mysql://localhost::3307/productos","root","1234");
        st=conexion.createStatement();
        rs=st.executeQuery("select * from productos_demo;");
        rs.next();
        
        this.jtf_id.setText(rs.getString("id_productos"));
        this.jtf_nombre.setText(rs.getString("nombre_producto"));
        this.jtf_marca.setText(rs.getString("marca"));
        this.jtf_existencias.setText(rs.getString("existencias"));
    }//try
    catch(SQLException err){
        JOptionPane.showMessageDialog(null,"Error " + err.getMessage());
    }//catch
}
    private void jb_primeroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_primeroMouseClicked
    try{
        if(rs.isLast()==false){
            rs.first();
       
    this.jtf_id.setText(rs.getString("id_productos"));
    this.jtf_nombre.setText(rs.getString("nombre_producto"));
    this.jtf_marca.setText(rs.getString("marca"));
    this.jtf_existencias.setText(rs.getString("existencias"));
    }//if
    }//try
    catch(Exception err){
    JOptionPane.showMessageDialog(null,"Error " + err.getMessage());   
    }//catch
    }//GEN-LAST:event_jb_primeroMouseClicked

    private void jb_anteriorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_anteriorMouseClicked
     try{
        if(rs.isLast()==false){
            rs.previous();
       
    this.jtf_id.setText(rs.getString("id_productos"));
    this.jtf_nombre.setText(rs.getString("nombre_producto"));
    this.jtf_marca.setText(rs.getString("marca"));
    this.jtf_existencias.setText(rs.getString("existencias"));
    }//if
    }//try
    catch(Exception err){
    JOptionPane.showMessageDialog(null,"Error " + err.getMessage());   
    }//catch   
    }//GEN-LAST:event_jb_anteriorMouseClicked

    private void jb_siguienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_siguienteMouseClicked
    try{
        if(rs.isLast()==false){
            rs.next();
       
    this.jtf_id.setText(rs.getString("id_productos"));
    this.jtf_nombre.setText(rs.getString("nombre_producto"));
    this.jtf_marca.setText(rs.getString("marca"));
    this.jtf_existencias.setText(rs.getString("existencias"));
    }//if
    }//try
    catch(Exception err){
    JOptionPane.showMessageDialog(null,"Error " + err.getMessage());   
    }//catch      
    }//GEN-LAST:event_jb_siguienteMouseClicked

    private void jb_ultimoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_ultimoMouseClicked
     try{
        if(rs.isLast()==true){
            rs.last();
       
    this.jtf_id.setText(rs.getString("id_productos"));
    this.jtf_nombre.setText(rs.getString("nombre_producto"));
    this.jtf_marca.setText(rs.getString("marca"));
    this.jtf_existencias.setText(rs.getString("existencias"));
    }//if
    }//try
    catch(Exception err){
    JOptionPane.showMessageDialog(null,"Error " + err.getMessage());   
    }//catch         
    }//GEN-LAST:event_jb_ultimoMouseClicked

    private void jb_guardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_guardarMouseClicked
    try{
    String id_productos=this.jtf_id.getText();
    String nombre_producto=this.jtf_nombre.getText();
    String marca=this.jtf_marca.getText();
    String exitencias=this.jtf_existencias.getText();
    
    st.executeUpdate("Insert into productos_demo(id_productos, nombre_producto, marca, existencias)"+"values('"+jtf_id+"','"+jtf_nombre+"','"+jtf_marca+"','"+jtf_existencias+"');");
    this.jb_primeroMouseClicked();
    }//try
    catch(SQLException err){
        JOptionPane.showMessageDialog(null,"Error "+err.getMessage()); 
    }//catch
    }//GEN-LAST:event_jb_guardarMouseClicked

    private void jb_nuevoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_nuevoMouseClicked
       
    }//GEN-LAST:event_jb_nuevoMouseClicked

    private void jb_borrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_borrarMouseClicked
       try{ 
           st.executeUpdate("delete from productos where id_productos="+this.jtf_id.getText());

           this.primerMouseCliked();

       } catch(SQLException err){ 
            JOptionPane.showMessageDialog(null,"Error "+err.getMessage()); 
        }   
    }//GEN-LAST:event_jb_borrarMouseClicked

    private void jb_modificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_modificarMouseClicked
       
    }//GEN-LAST:event_jb_modificarMouseClicked

    private void jb_cancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_cancelarMouseClicked
       
    }//GEN-LAST:event_jb_cancelarMouseClicked


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formularios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formularios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formularios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formularios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formularios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton jb_anterior;
    private javax.swing.JButton jb_borrar;
    private javax.swing.JButton jb_cancelar;
    private javax.swing.JButton jb_guardar;
    private javax.swing.JButton jb_modificar;
    private javax.swing.JButton jb_nuevo;
    private javax.swing.JButton jb_primero;
    private javax.swing.JButton jb_siguiente;
    private javax.swing.JButton jb_ultimo;
    private javax.swing.JLabel jl_existencias;
    private javax.swing.JLabel jl_id;
    private javax.swing.JLabel jl_marca;
    private javax.swing.JLabel jl_nombre;
    private javax.swing.JPanel jp_controles;
    private javax.swing.JPanel jp_controles_movimiento;
    private javax.swing.JPanel jp_datos;
    private javax.swing.JTextField jtf_existencias;
    private javax.swing.JTextField jtf_id;
    private javax.swing.JTextField jtf_marca;
    private javax.swing.JTextField jtf_nombre;
    // End of variables declaration//GEN-END:variables
}
